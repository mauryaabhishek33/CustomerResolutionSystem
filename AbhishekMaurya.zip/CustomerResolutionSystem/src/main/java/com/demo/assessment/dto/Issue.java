package com.demo.assessment.dto;

import com.demo.assessment.utils.IssueType;
import lombok.*;

@Getter
@Builder
@AllArgsConstructor
@ToString
@NoArgsConstructor
public class Issue {

    private static int counter = 0;
    private Integer issueId;
    private String transactionId;
    private IssueType issueType;
    private String subject;
    private String description;
    private String email;
    private String resolution;
    private Boolean resolved;
    private Agent agent;

    public Issue(String description, String email, IssueType issueType, String subject, String transactionId) {

        this.description = description;
        this.email = email;
        this.issueId = ++counter;
        this.issueType = issueType;
        this.resolution = null;
        this.resolved = false;
        this.subject = subject;
        this.transactionId = transactionId;
        this.agent = null;
    }

    public void resolveIssue(String resolution) {
        this.resolution = resolution;
        this.resolved = true;
    }

    public void assignAgent(Agent agent) {
        this.agent = agent;
    }
}
