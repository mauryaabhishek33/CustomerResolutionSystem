package com.demo.assessment.service;

import com.demo.assessment.dto.Issue;

import java.util.List;

public interface AgentService {

    List<Issue> getIssues(Integer issueId);

    List<Issue> getIssues(String customerEmail);

    void updateIssue(Integer issueId,Boolean status, String resolution);

    void resolveIssue(Integer issueId, String resolution);

}
