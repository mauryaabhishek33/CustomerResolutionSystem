package com.demo.assessment.service;

import com.demo.assessment.dto.Agent;
import com.demo.assessment.dto.Issue;
import com.demo.assessment.utils.IssueType;

import java.util.List;

public interface AdminService {

    Agent addAgent(String agentEmail, String agentName , List<IssueType> expertise);

//    List<Issue> viewAgentsWorkHistory();
}
