package com.demo.assessment.dto;

import com.demo.assessment.utils.IssueType;
import lombok.*;

import javax.xml.crypto.dsig.keyinfo.X509IssuerSerial;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Getter
@Builder
@AllArgsConstructor
@ToString
@NoArgsConstructor
public class Agent {
    private String email;
    private String name;
    private Set<IssueType> expertise;
    private List<Issue> assignedIssues;

    public Agent(String email, List<IssueType> expertise, String name) {
        this.assignedIssues = new ArrayList<>();
        this.email = email;
        this.expertise = new HashSet<>(expertise);
        this.name = name;
    }

    public  boolean canHandleIssue(Issue issue) {
        return expertise.contains(issue.getIssueType());
    }

    public void assignIssue(Issue issue ) {
        assignedIssues.add(issue);
    }

    public List<Issue> getAssignedIssues() {
        return assignedIssues;
    }
}
