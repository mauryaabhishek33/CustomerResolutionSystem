package com.demo.assessment.service;

import com.demo.assessment.dto.Agent;
import com.demo.assessment.dto.Issue;
import com.demo.assessment.utils.IssueType;

import java.util.List;

public class AdminServiceImpl implements AdminService {

    @Override
    public Agent addAgent(String agentEmail, String agentName, List<IssueType> expertise) {
        Agent agent =  new Agent(agentName,expertise,agentName);
        return agent;
    }

}
