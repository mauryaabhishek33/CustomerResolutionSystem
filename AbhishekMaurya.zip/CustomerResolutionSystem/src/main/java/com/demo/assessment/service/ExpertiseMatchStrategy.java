package com.demo.assessment.service;

public class ExpertiseMatchStrategy implements AssignmentStrategy {
    @Override
    public void assignIssue(Integer issueId) {
        //TODO move logic from CustomerIssueResolutionSystem to here
    }
}
