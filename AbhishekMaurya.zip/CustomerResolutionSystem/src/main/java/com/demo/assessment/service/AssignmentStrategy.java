package com.demo.assessment.service;

public interface AssignmentStrategy {

    void assignIssue(Integer issueId);
}
