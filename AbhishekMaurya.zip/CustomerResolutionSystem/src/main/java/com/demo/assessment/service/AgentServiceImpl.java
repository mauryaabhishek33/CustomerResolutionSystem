package com.demo.assessment.service;

import com.demo.assessment.dto.Issue;

import java.util.List;

public class AgentServiceImpl implements AgentService{
    @Override
    public List<Issue> getIssues(Integer issueId) {
        //TODO move logic from CustomerIssueResolutionSystem to here
        return null;
    }

    @Override
    public List<Issue> getIssues(String customerEmail) {
        //TODO move logic from CustomerIssueResolutionSystem to here
        return null;
    }

    @Override
    public void updateIssue(Integer issueId, Boolean status, String resolution) {
        //TODO move logic from CustomerIssueResolutionSystem to here

    }

    @Override
    public void resolveIssue(Integer issueId, String resolution) {

        //TODO move logic from CustomerIssueResolutionSystem to here
    }
}
